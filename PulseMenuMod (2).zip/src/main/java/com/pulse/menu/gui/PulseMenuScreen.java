package com.pulse.menu.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;

/**
 * Пустое меню в стиле "pulse visual":
 * тёмная панель по центру экрана, пульсирующая неоновая обводка,
 * заголовок с градиентом. Контент будем добавлять по шагам дальше.
 */
public class PulseMenuScreen extends Screen {

    private int panelWidth = 260;
    private int panelHeight = 160;

    public PulseMenuScreen() {
        super(new StringTextComponent("Pulse Menu"));
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        // Затемняем и слегка блюрим фон игры (ваниль это умеет через renderBackground)
        renderBackground(matrixStack);

        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int left = centerX - panelWidth / 2;
        int top = centerY - panelHeight / 2;
        int right = left + panelWidth;
        int bottom = top + panelHeight;

        // "Пульс" — плавная анимация свечения на основе времени
        long time = System.currentTimeMillis();
        float pulse = (float) (Math.sin(time / 350.0) * 0.5 + 0.5); // 0..1

        // Основной цвет темы — фиолетово-голубой градиент
        int colorA = lerpColor(0xFF7C3AED, 0xFF22D3EE, pulse); // фиолет -> циан
        int colorB = lerpColor(0xFF22D3EE, 0xFF7C3AED, pulse);

        // Тело панели — тёмная полупрозрачная подложка
        fillRounded(matrixStack, left, top, right, bottom, 0xE6101014, 6);

        // Внешнее свечение (несколько слоёв полупрозрачных рамок)
        drawGlowBorder(matrixStack, left, top, right, bottom, colorA, pulse);

        // Тонкая внутренняя рамка
        drawBorderLine(matrixStack, left, top, right, bottom, 0x33FFFFFF);

        // Верхняя полоса заголовка с градиентом темы
        fillGradientH(matrixStack, left + 2, top + 2, right - 2, top + 24, colorA, colorB);

        // Заголовок
        String title = "P U L S E";
        int titleWidth = font.getStringWidth(title);
        drawCenteredString(matrixStack, font, title, centerX, top + 8, 0xFFFFFFFF);

        // Подзаголовок — статус (меню пока пустое)
        String subtitle = "menu is ready \u00B7 content coming soon";
        font.drawString(matrixStack, subtitle, left + 12, top + 34, 0xFF9CA3AF);

        // Разделительная линия под заголовком
        fill(matrixStack, left + 12, top + 46, right - 12, top + 47, 0x22FFFFFF);

        // Пустая область содержимого — просто мягкая рамка-placeholder
        int contentTop = top + 56;
        int contentBottom = bottom - 12;
        fillRounded(matrixStack, left + 12, contentTop, right - 12, contentBottom, 0x33161620, 4);
        String placeholder = "\u2014 empty \u2014";
        drawCenteredString(matrixStack, font, placeholder, centerX, (contentTop + contentBottom) / 2 - 4, 0xFF6B7280);

        super.render(matrixStack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean isPauseScreen() {
        return false; // не ставим игру на паузу в одиночной игре
    }

    // ---------- вспомогательные методы рисования ----------

    private void fillRounded(MatrixStack ms, int x1, int y1, int x2, int y2, int color, int corner) {
        // Простая имитация скруглённых углов срезанием пикселей по краям
        fill(ms, x1 + corner, y1, x2 - corner, y2, color);
        fill(ms, x1, y1 + corner, x2, y2 - corner, color);
        fill(ms, x1 + corner, y1 + corner / 2, x2 - corner, y1 + corner, color);
    }

    private void fillGradientH(MatrixStack ms, int x1, int y1, int x2, int y2, int colorLeft, int colorRight) {
        // Горизонтальный градиент рисуем узкими вертикальными полосками
        int steps = Math.max(1, (x2 - x1));
        for (int i = 0; i < steps; i += 2) {
            float t = (float) i / steps;
            int c = lerpColor(colorLeft, colorRight, t);
            fill(ms, x1 + i, y1, Math.min(x1 + i + 2, x2), y2, c);
        }
    }

    private void drawBorderLine(MatrixStack ms, int x1, int y1, int x2, int y2, int color) {
        fill(ms, x1, y1, x2, y1 + 1, color);
        fill(ms, x1, y2 - 1, x2, y2, color);
        fill(ms, x1, y1, x1 + 1, y2, color);
        fill(ms, x2 - 1, y1, x2, y2, color);
    }

    private void drawGlowBorder(MatrixStack ms, int x1, int y1, int x2, int y2, int color, float pulse) {
        int layers = 4;
        for (int i = layers; i >= 1; i--) {
            int alpha = (int) (18 * pulse + 6) * i / layers + 4;
            int glowColor = (alpha << 24) | (color & 0xFFFFFF);
            fill(ms, x1 - i, y1 - i, x2 + i, y1, glowColor);
            fill(ms, x1 - i, y2, x2 + i, y2 + i, glowColor);
            fill(ms, x1 - i, y1 - i, x1, y2 + i, glowColor);
            fill(ms, x2, y1 - i, x2 + i, y2 + i, glowColor);
        }
    }

    private int lerpColor(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
