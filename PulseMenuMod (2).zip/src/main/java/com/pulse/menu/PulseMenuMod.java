package com.pulse.menu;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.api.distmarker.Dist;

@Mod("pulsemenu")
public class PulseMenuMod {

    public static final String MOD_ID = "pulsemenu";

    public PulseMenuMod() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new ClientHandler());
        }
    }
}
