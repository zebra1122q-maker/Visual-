package com.pulse.menu;

import com.pulse.menu.gui.PulseMenuScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.InputEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class ClientHandler {

    // Правый Shift
    private static final int KEY_RIGHT_SHIFT = GLFW.GLFW_KEY_RIGHT_SHIFT;

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getInstance();

        // Открываем меню только когда мы в игре и никакой другой экран не открыт
        if (event.getKey() == KEY_RIGHT_SHIFT
                && event.getAction() == GLFW.GLFW_PRESS
                && mc.player != null
                && mc.currentScreen == null) {
            mc.displayGuiScreen(new PulseMenuScreen());
        }
    }
}
